package com.example.krillinat0r.myapplication;

/**
 * Created by Krillinat0r on 13-04-2018.
 */

public class CurrencyMapValue
{
    private String name;
    private String key;
    private String imageUrl;

    public CurrencyMapValue(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
